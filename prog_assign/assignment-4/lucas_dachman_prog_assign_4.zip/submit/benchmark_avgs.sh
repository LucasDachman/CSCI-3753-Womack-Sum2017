./run_benchmarks.sh "output-1"
./run_benchmarks.sh "output-2"
./run_benchmarks.sh "output-3"


##### character device driver/module #####
- run ./install_module
- run ./test
